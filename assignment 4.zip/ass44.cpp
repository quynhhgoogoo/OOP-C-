//A program in which you use recursion to calculate the following sums:
//1⁄2 + 1⁄4 + 1⁄6+...+1⁄2n
//-1⁄3 * -2⁄5 * -3⁄7*...*-n⁄(2n+1)

#include <iostream>
using namespace std;

float sum1(int end1);
float sum2(int end2);

int main(void) {
int end1, end2;

cout<<"Enter your final number of denominator part :";
cin>>end1;

cout<<"Enter your final number of numerator part :";
cin>>end2;

cout<<"Sum of the 1st equation is : "<<sum1(end1)<<endl;
cout<<"Sum of the 2nd equation is : "<<sum2(end2)<<endl;

return 0;
}

float sum1(int end1){
	float si1=0, s1;
	int i=2;
	if(end1%2!=0)	cout<<"Wrong. Enter a number that is divisible to 2"<<endl;
	else
		while(i<end1/2){
			si1=1/i;
			s1= s1+si1;
			i=i+2;
		}
	return s1;
	}
float sum2(int end2){
	float si2=0, s2;
	for(int j=1; j<=end2; j++){
		for(int k=(2*j)+1; k<=end2; k++){
			si2= - j/k;
			s2 = s2 + si2;
		}
		return s2;
	}
}
