//A program which reads five decimal numbers from the keyboard and stores them to an array. 
//Use a pointer to calculate the sum of numbers in the array and print the result to the standard output device.

#include <iostream>

using namespace std;

int main(){
	double a1, a2, a3, a4, a5;	//defines five decimal numbers needed
	cout<<"Enter first decimal number :"<<endl;
	cin>>a1;
	cout<<"Enter second decimal number :"<<endl;
	cin>>a2;
	cout<<"Enter third decimal number :"<<endl;
	cin>>a3;
	cout<<"Enter 4th decimal number :"<<endl;
	cin>>a4;
	cout<<"Enter 5th decimal number :"<<endl;
	cin>>a5;
	
	double num[5] = {a1, a2, a3, a4, a5}, *p;
	p =num; 
	cout<<p[1]+p[2]+p[3]+p[4]+p[0]<<endl;
	
}
